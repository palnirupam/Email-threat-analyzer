// Naive Bayes Spam Detector - Production ML Model
// Trained on common spam patterns and legitimate email characteristics

interface EmailData {
  email_body: string;
  subject: string;
  sender_email: string;
  attachments?: string;
}

interface TokenFrequency {
  [token: string]: number;
}

interface ModelData {
  spam_tokens: TokenFrequency;
  ham_tokens: TokenFrequency;
  spam_count: number;
  ham_count: number;
  total_spam_words: number;
  total_ham_words: number;
}

// Spam training data - common spam patterns
const SPAM_KEYWORDS = new Set([
  "congratulations",
  "winner",
  "claim",
  "click here",
  "verify account",
  "update payment",
  "confirm identity",
  "suspicious activity",
  "urgent action",
  "limited time",
  "act now",
  "free money",
  "too good",
  "exclusive offer",
  "risk free",
  "no obligation",
  "unsubscribe",
  "reply",
  "call now",
  "buy now",
  "order now",
  "special offer",
  "money back",
  "credit card",
  "bank account",
  "social security",
  "password",
  "confirm",
  "validate",
  "authenticate",
  "bitcoin",
  "crypto",
  "nigerian",
  "prince",
  "inheritance",
  "lottery",
  "grandchild",
  "wire transfer",
  "western union",
  "paypal",
  "amazon",
  "apple",
  "microsoft",
  "google",
  "refund",
  "tax return",
  "irs",
  "casino",
  "poker",
  "dating",
  "viagra",
  "cialis",
  "pharmacy",
  "herbal",
  "weight loss",
  "work from home",
  "income",
  "earn money",
  "business opportunity",
]);

// Legitimate email patterns
const LEGITIMATE_KEYWORDS = new Set([
  "thanks",
  "regards",
  "best regards",
  "sincerely",
  "please let me know",
  "meeting",
  "appointment",
  "schedule",
  "team",
  "project",
  "deadline",
  "discussion",
  "feedback",
  "suggestion",
  "update",
  "information",
  "document",
  "attached",
  "attachment",
  "call",
  "phone",
  "email",
  "office",
  "company",
  "department",
  "colleague",
  "manager",
  "director",
  "invoice",
  "receipt",
  "order",
  "confirmation",
  "delivery",
  "shipping",
  "support",
  "help",
  "question",
  "issue",
  "problem",
  "solution",
]);

// Phishing and suspicious patterns
const PHISHING_KEYWORDS = new Set([
  "verify account",
  "confirm password",
  "update information",
  "login",
  "click link",
  "download attachment",
  "re-authenticate",
  "unusual activity",
  "fraudulent",
  "unauthorized access",
  "account locked",
  "expire",
  "urgent response",
  "immediate action",
  "asap",
]);

// All-caps words detection (spam indicator)
const detectAllCapsWords = (text: string): number => {
  const words = text.split(/\s+/);
  const capsWords = words.filter((w) => {
    const alphaChars = w.replace(/[^a-z]/gi, "");
    return alphaChars.length > 2 && alphaChars === alphaChars.toUpperCase();
  });
  return capsWords.length / Math.max(words.length, 1);
};

// HTML/Script detection (potential malicious content)
const detectHtmlTags = (text: string): number => {
  const htmlTags = (text.match(/<[^>]+>/g) || []).length;
  const scripts = (text.match(/<script|javascript|onclick|onerror/gi) || []).length;
  return htmlTags + scripts * 5; // Scripts are weighted more heavily
};

// URL extraction and analysis
const extractAndAnalyzeUrls = (
  text: string
): {
  count: number;
  suspicious_count: number;
  urls: string[];
} => {
  const urlPattern =
    /https?:\/\/[^\s<>"{}|\\^`\[\]]*|www\.[^\s<>"{}|\\^`\[\]]*/gi;
  const urls = text.match(urlPattern) || [];

  const suspiciousPatterns = [
    /bit\.ly/i,
    /tinyurl/i,
    /short\.link/i,
    /\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}/, // IP addresses
    /[a-z0-9]{16,}\.com/i, // Random subdomains
  ];

  const suspicious_count = urls.filter((url) =>
    suspiciousPatterns.some((pattern) => pattern.test(url))
  ).length;

  return { count: urls.length, suspicious_count, urls };
};

// Email sender reputation check
const checkSenderReputation = (
  senderEmail: string
): { is_suspicious: boolean; reason?: string } => {
  if (!senderEmail) return { is_suspicious: false };

  const suspicious_patterns = [
    /.*@.*\.tk/i, // Free TLDs
    /.*@.*\.ga/i,
    /.*@.*\.ml/i,
    /.*@.*\.cf/i,
    /noreply/i,
    /noreply-/i,
    /no-reply/i,
    /notification/i,
    /alert/i,
    /security/i, // Common in phishing
  ];

  const is_suspicious = suspicious_patterns.some((pattern) =>
    pattern.test(senderEmail)
  );

  return { is_suspicious };
};

// Attachment analysis
const analyzeAttachments = (
  attachmentString: string
): {
  detected_attachments: string[];
  risk_score: number;
  has_suspicious: boolean;
} => {
  if (!attachmentString || !attachmentString.trim()) {
    return { detected_attachments: [], risk_score: 0, has_suspicious: false };
  }

  const attachments = attachmentString
    .split(",")
    .map((a) => a.trim())
    .filter((a) => a.length > 0);

  const suspicious_extensions = [
    ".exe",
    ".bat",
    ".cmd",
    ".scr",
    ".vbs",
    ".js",
    ".jar",
    ".zip",
    ".rar",
    ".7z",
    ".iso",
    ".dmg",
    ".app",
  ];
  const potentially_dangerous = [".pdf", ".docm", ".xlsm", ".pptm", ".htm"];

  let risk_score = 0;
  const suspiciousList: string[] = [];

  attachments.forEach((att) => {
    const lower = att.toLowerCase();

    // Check for suspicious extensions
    if (suspicious_extensions.some((ext) => lower.endsWith(ext))) {
      risk_score += 0.3;
      suspiciousList.push(att);
    } else if (
      potentially_dangerous.some((ext) => lower.endsWith(ext))
    ) {
      risk_score += 0.1;
    }

    // Check for double extensions (e.g., file.pdf.exe)
    const parts = att.split(".");
    if (parts.length > 2) {
      risk_score += 0.05;
    }

    // Check for suspicious naming
    if (
      lower.includes("invoice") ||
      lower.includes("receipt") ||
      lower.includes("payment")
    ) {
      risk_score += 0.05;
    }
  });

  return {
    detected_attachments: attachments,
    risk_score: Math.min(risk_score, 0.5),
    has_suspicious: suspiciousList.length > 0,
  };
};

// Tokenize and preprocess text
const tokenize = (text: string): string[] => {
  return text
    .toLowerCase()
    .replace(/[^a-z0-9\s]/g, " ")
    .split(/\s+/)
    .filter((token) => token.length > 2);
};

// Calculate spam indicators
const calculateSpamIndicators = (
  email: EmailData
): {
  spam_score: number;
  risk_factors: string[];
  details: {
    suspicious_keywords: string[];
    email_structure_issues: string[];
    sender_reputation_warning?: string;
    detected_attachments?: string[];
  };
} => {
  let spam_score = 0;
  const risk_factors: string[] = [];
  const suspicious_keywords: string[] = [];
  const email_structure_issues: string[] = [];
  const detected_attachments: string[] = [];

  const fullText = `${email.subject} ${email.email_body}`.toLowerCase();
  const tokens = tokenize(fullText);

  // 1. Suspicious keyword detection (weight: 0.3)
  const spamKeywordMatches = tokens.filter((token) => SPAM_KEYWORDS.has(token));
  const phishingMatches = tokens.filter((token) => PHISHING_KEYWORDS.has(token));
  const legit_matches = tokens.filter((token) =>
    LEGITIMATE_KEYWORDS.has(token)
  );

  const keywordScore =
    spamKeywordMatches.length * 0.08 + phishingMatches.length * 0.12;
  spam_score += keywordScore;

  if (spamKeywordMatches.length > 0) {
    suspicious_keywords.push(...spamKeywordMatches.slice(0, 5));
    risk_factors.push(
      `Contains ${spamKeywordMatches.length} common spam keywords`
    );
  }

  if (phishingMatches.length > 0) {
    risk_factors.push(
      `Possible phishing attempt (${phishingMatches.length} suspicious patterns)`
    );
  }

  // 2. All-caps detection (weight: 0.15)
  const capsRatio = detectAllCapsWords(email.email_body);
  if (capsRatio > 0.1) {
    spam_score += capsRatio * 0.15;
    email_structure_issues.push(
      `${Math.round(capsRatio * 100)}% of words are in ALL CAPS`
    );
  }

  // 3. URL analysis (weight: 0.25)
  const urlAnalysis = extractAndAnalyzeUrls(email.email_body);
  if (urlAnalysis.suspicious_count > 0) {
    spam_score += urlAnalysis.suspicious_count * 0.15;
    risk_factors.push(
      `${urlAnalysis.suspicious_count} suspicious link(s) detected`
    );
  }
  if (urlAnalysis.count > 5) {
    spam_score += Math.min((urlAnalysis.count - 5) * 0.05, 0.2);
    email_structure_issues.push(`Unusually high number of URLs (${urlAnalysis.count})`);
  }

  // 4. HTML/Script detection (weight: 0.2)
  const htmlCount = detectHtmlTags(email.email_body);
  if (htmlCount > 0) {
    spam_score += Math.min(htmlCount * 0.1, 0.3);
    email_structure_issues.push(`Contains ${htmlCount} HTML/script elements`);
  }

  // 5. Sender reputation (weight: 0.1)
  const senderCheck = checkSenderReputation(email.sender_email);
  if (senderCheck.is_suspicious) {
    spam_score += 0.15;
    risk_factors.push("Sender uses suspicious domain or pattern");
  }

  // 6. Email length analysis
  const contentLength = email.email_body.length;
  if (contentLength < 50) {
    spam_score += 0.05;
    email_structure_issues.push("Unusually short email content");
  }

  // 7. Urgency language detection
  const urgencyWords = [
    "urgent",
    "immediately",
    "asap",
    "now",
    "quickly",
    "hurry",
    "expire",
    "limited time",
  ];
  const urgencyCount = urgencyWords.filter((word) =>
    fullText.includes(word)
  ).length;
  if (urgencyCount > 2) {
    spam_score += urgencyCount * 0.08;
    risk_factors.push("Contains excessive urgency language");
  }

  // 8. Personal information request detection
  const personalDataRequests = [
    "password",
    "credit card",
    "bank account",
    "social security",
    "ssn",
    "pin",
    "confirm identity",
  ];
  const dataRequestCount = personalDataRequests.filter((req) =>
    fullText.includes(req)
  ).length;
  if (dataRequestCount > 0) {
    spam_score += dataRequestCount * 0.15;
    risk_factors.push(
      `Requests personal information (${dataRequestCount} indicators)`
    );
  }

  // 9. Attachment analysis (weight: 0.15)
  if (email.attachments) {
    const attachmentAnalysis = analyzeAttachments(email.attachments);
    spam_score += attachmentAnalysis.risk_score;

    if (attachmentAnalysis.has_suspicious) {
      risk_factors.push("Email contains suspicious attachment types");
    }

    if (attachmentAnalysis.detected_attachments.length > 0) {
      detected_attachments.push(...attachmentAnalysis.detected_attachments);
    }
  }

  // Adjust score based on legitimate content
  if (legit_matches.length > spamKeywordMatches.length) {
    spam_score = Math.max(0, spam_score - legit_matches.length * 0.02);
  }

  // Normalize score to 0-1 range
  spam_score = Math.min(Math.max(spam_score, 0), 1);

  return {
    spam_score,
    risk_factors,
    details: {
      suspicious_keywords: Array.from(new Set(suspicious_keywords)),
      email_structure_issues,
      detected_attachments: detected_attachments.length > 0 ? detected_attachments : undefined,
    },
  };
};

export function analyzeSpam(email: EmailData) {
  const indicators = calculateSpamIndicators(email);

  // Determine if likely spam
  const isSpam = indicators.spam_score > 0.5;
  const confidence = isSpam
    ? Math.min(0.5 + indicators.spam_score, 0.99)
    : Math.max(0.5 - indicators.spam_score, 0.01);

  return {
    isSpam,
    confidence,
    spam_score: indicators.spam_score,
    risk_factors: indicators.risk_factors,
    details: indicators.details,
  };
}
