import { RequestHandler } from "express";
import { analyzeSpam } from "../ml/spam-detector";

interface AnalyzeSpamRequest {
  email_body: string;
  subject: string;
  sender_email: string;
  attachments?: string;
}

export const handleSpamAnalysis: RequestHandler = (req, res) => {
  try {
    const { email_body, subject, sender_email, attachments } = req.body as AnalyzeSpamRequest;

    // Validation
    if (!email_body && !subject) {
      return res.status(400).json({
        error: "Email body or subject is required",
      });
    }

    // Analyze spam
    const result = analyzeSpam({
      email_body: email_body || "",
      subject: subject || "",
      sender_email: sender_email || "",
      attachments: attachments || "",
    });

    res.json(result);
  } catch (error) {
    console.error("Spam analysis error:", error);
    res.status(500).json({
      error: "Failed to analyze email",
    });
  }
};
