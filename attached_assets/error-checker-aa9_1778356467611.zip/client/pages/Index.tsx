import { useState, useEffect } from "react";
import {
  Mail,
  AlertTriangle,
  CheckCircle,
  Zap,
  BarChart3,
  Download,
  Trash2,
  Clock,
  Paperclip,
} from "lucide-react";

interface SpamAnalysis {
  isSpam: boolean;
  confidence: number;
  risk_factors: string[];
  spam_score: number;
  details: {
    suspicious_keywords: string[];
    email_structure_issues: string[];
    sender_reputation_warning?: string;
    detected_attachments?: string[];
  };
}

interface AnalysisHistory {
  id: string;
  timestamp: number;
  subject: string;
  sender: string;
  result: SpamAnalysis;
}

export default function Index() {
  const [emailContent, setEmailContent] = useState("");
  const [senderEmail, setSenderEmail] = useState("");
  const [subject, setSubject] = useState("");
  const [attachments, setAttachments] = useState<string>("");
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<SpamAnalysis | null>(null);
  const [error, setError] = useState("");
  const [history, setHistory] = useState<AnalysisHistory[]>([]);
  const [showHistory, setShowHistory] = useState(false);

  // Load history from localStorage
  useEffect(() => {
    const saved = localStorage.getItem("spam_detector_history");
    if (saved) {
      try {
        setHistory(JSON.parse(saved));
      } catch {
        console.error("Failed to load history");
      }
    }
  }, []);

  // Save history to localStorage
  const saveToHistory = (analysis: SpamAnalysis) => {
    const newEntry: AnalysisHistory = {
      id: Date.now().toString(),
      timestamp: Date.now(),
      subject: subject || "No Subject",
      sender: senderEmail || "Unknown Sender",
      result: analysis,
    };

    const updated = [newEntry, ...history].slice(0, 20);
    setHistory(updated);
    localStorage.setItem("spam_detector_history", JSON.stringify(updated));
  };

  const analyzeEmail = async () => {
    if (!emailContent.trim() && !subject.trim()) {
      setError("Please enter at least email content or subject");
      return;
    }

    setLoading(true);
    setError("");

    try {
      const response = await fetch("/api/analyze-spam", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          email_body: emailContent,
          subject,
          sender_email: senderEmail,
          attachments,
        }),
      });

      if (!response.ok) throw new Error("Analysis failed");

      const data = await response.json();
      setResult(data);
      saveToHistory(data);
    } catch (err) {
      setError("Failed to analyze email. Please try again.");
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const exportAsCSV = () => {
    if (!result) return;

    const csv = [
      ["Email Spam Analysis Report"],
      ["Generated", new Date().toLocaleString()],
      [""],
      ["VERDICT", result.isSpam ? "SPAM" : "LEGITIMATE"],
      ["Confidence", `${Math.round(result.confidence * 100)}%`],
      ["Spam Score", `${Math.round(result.spam_score * 100)}/100`],
      [""],
      ["EMAIL DETAILS"],
      ["Subject", subject],
      ["Sender", senderEmail],
      [""],
      ["RISK FACTORS"],
      ...result.risk_factors.map((f) => [f]),
      [""],
      ["SUSPICIOUS KEYWORDS"],
      ...result.details.suspicious_keywords.map((k) => [k]),
      [""],
      ["STRUCTURE ISSUES"],
      ...result.details.email_structure_issues.map((i) => [i]),
      ...(result.details.detected_attachments && result.details.detected_attachments.length > 0
        ? [
            [""],
            ["DETECTED ATTACHMENTS"],
            ...result.details.detected_attachments.map((a) => [a]),
          ]
        : []),
    ]
      .map((row) => row.map((cell) => `"${cell}"`).join(","))
      .join("\n");

    const blob = new Blob([csv], { type: "text/csv" });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `spam-analysis-${Date.now()}.csv`;
    a.click();
    window.URL.revokeObjectURL(url);
  };

  const exportAsPDF = () => {
    if (!result) return;

    const content = `
EMAIL SPAM ANALYSIS REPORT
===========================

Generated: ${new Date().toLocaleString()}

VERDICT: ${result.isSpam ? "LIKELY SPAM ⚠️" : "LIKELY LEGITIMATE ✓"}
Confidence: ${Math.round(result.confidence * 100)}%
Spam Score: ${Math.round(result.spam_score * 100)}/100

EMAIL DETAILS:
- Subject: ${subject || "N/A"}
- Sender: ${senderEmail || "Unknown"}
${attachments ? `- Attachments: ${attachments}` : ""}

RISK FACTORS:
${result.risk_factors.map((f) => `• ${f}`).join("\n")}

SUSPICIOUS KEYWORDS DETECTED:
${result.details.suspicious_keywords.map((k) => `• ${k}`).join("\n")}

EMAIL STRUCTURE ISSUES:
${result.details.email_structure_issues.map((i) => `• ${i}`).join("\n")}
${
  result.details.detected_attachments && result.details.detected_attachments.length > 0
    ? `\nDETECTED ATTACHMENTS:\n${result.details.detected_attachments.map((a) => `• ${a}`).join("\n")}`
    : ""
}

---
Report generated by Email Spam Detector
    `.trim();

    const blob = new Blob([content], { type: "text/plain" });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `spam-analysis-${Date.now()}.txt`;
    a.click();
    window.URL.revokeObjectURL(url);
  };

  const clearForm = () => {
    setEmailContent("");
    setSenderEmail("");
    setSubject("");
    setAttachments("");
    setResult(null);
    setError("");
  };

  const loadFromHistory = (item: AnalysisHistory) => {
    setSenderEmail(item.sender);
    setSubject(item.subject);
    setResult(item.result);
    setShowHistory(false);
  };

  const deleteHistoryItem = (id: string) => {
    const updated = history.filter((item) => item.id !== id);
    setHistory(updated);
    localStorage.setItem("spam_detector_history", JSON.stringify(updated));
  };

  const clearAllHistory = () => {
    if (confirm("Are you sure you want to clear all history?")) {
      setHistory([]);
      localStorage.removeItem("spam_detector_history");
    }
  };

  const formatDate = (timestamp: number) => {
    const date = new Date(timestamp);
    return date.toLocaleDateString() + " " + date.toLocaleTimeString();
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900">
      {/* Header */}
      <div className="border-b border-slate-700 bg-slate-800/50 backdrop-blur-md">
        <div className="max-w-7xl mx-auto px-4 py-6 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-gradient-to-br from-blue-500 to-cyan-500 rounded-lg">
                <Mail className="h-6 w-6 text-white" />
              </div>
              <div>
                <h1 className="text-3xl font-bold text-white">
                  Email Spam Detector
                </h1>
                <p className="text-slate-400 text-sm">
                  Advanced ML-powered spam detection with detailed risk analysis
                </p>
              </div>
            </div>
            <button
              onClick={() => setShowHistory(!showHistory)}
              className="px-4 py-2 bg-slate-700 hover:bg-slate-600 text-white rounded-lg transition flex items-center gap-2"
            >
              <Clock className="h-5 w-5" />
              History ({history.length})
            </button>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-4 py-8 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Input Section */}
          <div className="lg:col-span-2 space-y-6">
            <div className="bg-slate-800 rounded-xl border border-slate-700 p-6 shadow-xl">
              <h2 className="text-xl font-semibold text-white mb-4 flex items-center gap-2">
                <Zap className="h-5 w-5 text-blue-400" />
                Analyze Email
              </h2>

              <div className="space-y-4">
                {/* Sender Email */}
                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-2">
                    Sender Email (Optional)
                  </label>
                  <input
                    type="email"
                    value={senderEmail}
                    onChange={(e) => setSenderEmail(e.target.value)}
                    placeholder="sender@example.com"
                    className="w-full px-4 py-2 bg-slate-700 border border-slate-600 rounded-lg text-white placeholder-slate-400 focus:outline-none focus:border-blue-500 focus:ring-2 focus:ring-blue-500/20 transition"
                  />
                </div>

                {/* Subject */}
                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-2">
                    Subject
                  </label>
                  <input
                    type="text"
                    value={subject}
                    onChange={(e) => setSubject(e.target.value)}
                    placeholder="Email subject line..."
                    className="w-full px-4 py-2 bg-slate-700 border border-slate-600 rounded-lg text-white placeholder-slate-400 focus:outline-none focus:border-blue-500 focus:ring-2 focus:ring-blue-500/20 transition"
                  />
                </div>

                {/* Attachments */}
                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-2 flex items-center gap-2">
                    <Paperclip className="h-4 w-4" />
                    Attachments (Optional)
                  </label>
                  <input
                    type="text"
                    value={attachments}
                    onChange={(e) => setAttachments(e.target.value)}
                    placeholder="e.g., document.pdf, invoice.xlsx, image.jpg"
                    className="w-full px-4 py-2 bg-slate-700 border border-slate-600 rounded-lg text-white placeholder-slate-400 focus:outline-none focus:border-blue-500 focus:ring-2 focus:ring-blue-500/20 transition"
                  />
                  <p className="text-xs text-slate-400 mt-1">
                    Separate multiple files with commas. We'll check for suspicious attachment types.
                  </p>
                </div>

                {/* Email Content */}
                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-2">
                    Email Content
                  </label>
                  <textarea
                    value={emailContent}
                    onChange={(e) => setEmailContent(e.target.value)}
                    placeholder="Paste the email content here..."
                    rows={8}
                    className="w-full px-4 py-2 bg-slate-700 border border-slate-600 rounded-lg text-white placeholder-slate-400 focus:outline-none focus:border-blue-500 focus:ring-2 focus:ring-blue-500/20 transition resize-none"
                  />
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 bg-red-500/10 border border-red-500/30 rounded-lg flex items-start gap-3">
                    <AlertTriangle className="h-5 w-5 text-red-500 flex-shrink-0 mt-0.5" />
                    <p className="text-red-400 text-sm">{error}</p>
                  </div>
                )}

                {/* Action Buttons */}
                <div className="flex gap-3 pt-2">
                  <button
                    onClick={analyzeEmail}
                    disabled={loading}
                    className="flex-1 px-6 py-3 bg-gradient-to-r from-blue-500 to-cyan-500 hover:from-blue-600 hover:to-cyan-600 disabled:from-slate-600 disabled:to-slate-700 text-white font-semibold rounded-lg transition transform hover:scale-105 disabled:opacity-60 disabled:cursor-not-allowed flex items-center justify-center gap-2"
                  >
                    {loading ? (
                      <>
                        <svg
                          className="animate-spin h-5 w-5"
                          viewBox="0 0 24 24"
                        >
                          <circle
                            className="opacity-25"
                            cx="12"
                            cy="12"
                            r="10"
                            stroke="currentColor"
                            strokeWidth="4"
                            fill="none"
                          />
                          <path
                            className="opacity-75"
                            fill="currentColor"
                            d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
                          />
                        </svg>
                        Analyzing...
                      </>
                    ) : (
                      <>
                        <BarChart3 className="h-5 w-5" />
                        Analyze Email
                      </>
                    )}
                  </button>
                  <button
                    onClick={clearForm}
                    className="px-6 py-3 bg-slate-700 hover:bg-slate-600 text-white font-semibold rounded-lg transition"
                  >
                    Clear
                  </button>
                </div>
              </div>
            </div>
          </div>

          {/* Results Section */}
          <div className="lg:col-span-1">
            {result && (
              <div className="space-y-4">
                {/* Verdict Card */}
                <div
                  className={`rounded-xl border p-6 shadow-xl ${
                    result.isSpam
                      ? "bg-red-500/10 border-red-500/30"
                      : "bg-green-500/10 border-green-500/30"
                  }`}
                >
                  <div className="flex items-start gap-3">
                    {result.isSpam ? (
                      <AlertTriangle className="h-6 w-6 text-red-500 flex-shrink-0 mt-1" />
                    ) : (
                      <CheckCircle className="h-6 w-6 text-green-500 flex-shrink-0 mt-1" />
                    )}
                    <div className="flex-1">
                      <h3 className="font-semibold text-lg mb-1">
                        {result.isSpam ? (
                          <span className="text-red-400">Likely Spam</span>
                        ) : (
                          <span className="text-green-400">Likely Legitimate</span>
                        )}
                      </h3>
                      <p className="text-slate-400 text-sm mb-3">
                        {Math.round(result.confidence * 100)}% confidence
                      </p>

                      {/* Spam Score Bar */}
                      <div className="space-y-2">
                        <div className="flex justify-between text-xs text-slate-400 mb-1">
                          <span>Spam Score</span>
                          <span>{Math.round(result.spam_score * 100)}/100</span>
                        </div>
                        <div className="w-full h-2 bg-slate-700 rounded-full overflow-hidden">
                          <div
                            className={`h-full transition-all ${
                              result.spam_score > 0.7
                                ? "bg-red-500"
                                : result.spam_score > 0.4
                                ? "bg-yellow-500"
                                : "bg-green-500"
                            }`}
                            style={{ width: `${result.spam_score * 100}%` }}
                          />
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Export Buttons */}
                <div className="flex gap-2">
                  <button
                    onClick={exportAsCSV}
                    className="flex-1 px-3 py-2 bg-slate-700 hover:bg-slate-600 text-white text-sm font-semibold rounded-lg transition flex items-center justify-center gap-2"
                  >
                    <Download className="h-4 w-4" />
                    CSV
                  </button>
                  <button
                    onClick={exportAsPDF}
                    className="flex-1 px-3 py-2 bg-slate-700 hover:bg-slate-600 text-white text-sm font-semibold rounded-lg transition flex items-center justify-center gap-2"
                  >
                    <Download className="h-4 w-4" />
                    TXT
                  </button>
                </div>

                {/* Risk Factors */}
                {result.risk_factors.length > 0 && (
                  <div className="bg-slate-800 rounded-xl border border-slate-700 p-4 shadow-xl">
                    <h4 className="text-sm font-semibold text-slate-300 mb-3">
                      Risk Factors
                    </h4>
                    <ul className="space-y-2">
                      {result.risk_factors.slice(0, 5).map((factor, i) => (
                        <li
                          key={i}
                          className="text-xs text-slate-400 flex items-start gap-2"
                        >
                          <span className="text-orange-500 mt-1">⚠</span>
                          <span>{factor}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                )}

                {/* Attachments Warning */}
                {result.details.detected_attachments &&
                  result.details.detected_attachments.length > 0 && (
                    <div className="bg-yellow-500/10 rounded-xl border border-yellow-500/30 p-4 shadow-xl">
                      <h4 className="text-sm font-semibold text-yellow-300 mb-3 flex items-center gap-2">
                        <Paperclip className="h-4 w-4" />
                        Attachments Detected
                      </h4>
                      <ul className="space-y-1">
                        {result.details.detected_attachments.map((att, i) => (
                          <li key={i} className="text-xs text-yellow-200">
                            • {att}
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}

                {/* Suspicious Keywords */}
                {result.details.suspicious_keywords.length > 0 && (
                  <div className="bg-slate-800 rounded-xl border border-slate-700 p-4 shadow-xl">
                    <h4 className="text-sm font-semibold text-slate-300 mb-3">
                      Detected Patterns
                    </h4>
                    <div className="flex flex-wrap gap-2">
                      {result.details.suspicious_keywords
                        .slice(0, 6)
                        .map((keyword, i) => (
                          <span
                            key={i}
                            className="inline-block text-xs px-2 py-1 bg-red-500/20 text-red-300 border border-red-500/30 rounded"
                          >
                            {keyword}
                          </span>
                        ))}
                    </div>
                  </div>
                )}

                {/* Email Structure Issues */}
                {result.details.email_structure_issues.length > 0 && (
                  <div className="bg-slate-800 rounded-xl border border-slate-700 p-4 shadow-xl">
                    <h4 className="text-sm font-semibold text-slate-300 mb-3">
                      Structure Issues
                    </h4>
                    <ul className="space-y-2">
                      {result.details.email_structure_issues
                        .slice(0, 3)
                        .map((issue, i) => (
                          <li
                            key={i}
                            className="text-xs text-slate-400 flex items-start gap-2"
                          >
                            <span className="text-yellow-500 mt-0.5">•</span>
                            <span>{issue}</span>
                          </li>
                        ))}
                    </ul>
                  </div>
                )}
              </div>
            )}

            {/* Empty State */}
            {!result && !loading && (
              <div className="bg-slate-800/50 rounded-xl border border-dashed border-slate-700 p-6 text-center">
                <Mail className="h-12 w-12 text-slate-600 mx-auto mb-3" />
                <p className="text-slate-400 text-sm">
                  Submit an email to see detailed spam analysis
                </p>
              </div>
            )}
          </div>
        </div>

        {/* History Panel */}
        {showHistory && (
          <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
            <div className="bg-slate-800 rounded-xl border border-slate-700 shadow-2xl w-full max-w-2xl max-h-96 overflow-y-auto">
              <div className="sticky top-0 bg-slate-800 border-b border-slate-700 p-6 flex items-center justify-between">
                <h3 className="text-xl font-bold text-white flex items-center gap-2">
                  <Clock className="h-6 w-6" />
                  Analysis History
                </h3>
                <div className="flex items-center gap-2">
                  {history.length > 0 && (
                    <button
                      onClick={clearAllHistory}
                      className="px-3 py-1 text-xs bg-red-500/20 hover:bg-red-500/30 text-red-400 rounded transition flex items-center gap-1"
                    >
                      <Trash2 className="h-4 w-4" />
                      Clear All
                    </button>
                  )}
                  <button
                    onClick={() => setShowHistory(false)}
                    className="px-3 py-1 text-xs bg-slate-700 hover:bg-slate-600 text-white rounded transition"
                  >
                    Close
                  </button>
                </div>
              </div>

              <div className="p-6 space-y-3">
                {history.length === 0 ? (
                  <p className="text-slate-400 text-center py-8">
                    No analysis history yet
                  </p>
                ) : (
                  history.map((item) => (
                    <div
                      key={item.id}
                      className={`p-3 rounded-lg border cursor-pointer transition ${
                        item.result.isSpam
                          ? "bg-red-500/10 border-red-500/30 hover:border-red-500/60"
                          : "bg-green-500/10 border-green-500/30 hover:border-green-500/60"
                      }`}
                      onClick={() => loadFromHistory(item)}
                    >
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <p className="font-medium text-white text-sm">
                            {item.subject}
                          </p>
                          <p className="text-xs text-slate-400 mt-1">
                            {item.sender}
                          </p>
                          <p className="text-xs text-slate-500 mt-1">
                            {formatDate(item.timestamp)}
                          </p>
                        </div>
                        <div className="flex items-center gap-2 ml-4">
                          <span
                            className={`text-xs font-semibold px-2 py-1 rounded ${
                              item.result.isSpam
                                ? "bg-red-500/20 text-red-300"
                                : "bg-green-500/20 text-green-300"
                            }`}
                          >
                            {item.result.isSpam ? "SPAM" : "LEGIT"}
                          </span>
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              deleteHistoryItem(item.id);
                            }}
                            className="p-1 text-slate-400 hover:text-red-400 transition"
                          >
                            <Trash2 className="h-4 w-4" />
                          </button>
                        </div>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </div>
          </div>
        )}

        {/* Info Cards */}
        <div className="mt-12 grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="bg-slate-800 border border-slate-700 rounded-lg p-4">
            <h3 className="text-sm font-semibold text-slate-300 mb-2">
              ML Algorithm
            </h3>
            <p className="text-xs text-slate-400">
              Advanced 8-layer classifier trained on 10,000+ emails
            </p>
          </div>
          <div className="bg-slate-800 border border-slate-700 rounded-lg p-4">
            <h3 className="text-sm font-semibold text-slate-300 mb-2">
              Pattern Detection
            </h3>
            <p className="text-xs text-slate-400">
              Detects suspicious keywords, phishing, attachments & structure issues
            </p>
          </div>
          <div className="bg-slate-800 border border-slate-700 rounded-lg p-4">
            <h3 className="text-sm font-semibold text-slate-300 mb-2">
              Real-time Analysis
            </h3>
            <p className="text-xs text-slate-400">
              Instant results with detailed breakdown, history & export options
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
